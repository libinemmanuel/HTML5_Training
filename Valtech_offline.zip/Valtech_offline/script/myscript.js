window.onload = function(){
	for(var i = 0; i < document.getElementsByTagName("img"); i++){
		document.getElementsByTagName("img")[i].addEventListener("click", clickHandler)
	}
}
function clickHandler(evt){
	alert("you clicked "+evt.target.src)
}
