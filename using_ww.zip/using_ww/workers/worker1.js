for(var i = 0; i< 100000;i++){
// 	document.getElementById("display").innerHTML = i ;
	postMessage(i);
}